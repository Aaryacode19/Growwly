import { ReactNode, useState, useEffect } from 'react'
import { useAuth } from '../hooks/useAuth'
import { useTheme } from '../hooks/useTheme'
import { LogOut, Plus, Moon, Sun, Lock, Menu, X } from 'lucide-react'
import { Link, useLocation } from 'react-router-dom'
import { ChangePasswordModal } from './ChangePasswordModal'
import { Footer } from './Footer'
import { BotButton } from './BotButton'

interface LayoutProps {
  children: ReactNode
}

export function Layout({ children }: LayoutProps) {
  const { user, signOut } = useAuth()
  const { theme, toggleTheme, isTransitioning } = useTheme()
  const location = useLocation()
  const [showPasswordModal, setShowPasswordModal] = useState(false)
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)

  // Close mobile menu when route changes
  useEffect(() => {
    setMobileMenuOpen(false)
  }, [location.pathname])

  // Close mobile menu when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      const target = event.target as Element
      if (mobileMenuOpen && !target.closest('.mobile-menu') && !target.closest('.mobile-menu-button')) {
        setMobileMenuOpen(false)
      }
    }

    if (mobileMenuOpen) {
      document.addEventListener('click', handleClickOutside)
      return () => document.removeEventListener('click', handleClickOutside)
    }
  }, [mobileMenuOpen])

  const handleSignOut = async () => {
    await signOut()
    setMobileMenuOpen(false)
  }

  const closeMobileMenu = () => {
    setMobileMenuOpen(false)
  }

  return (
    <div className="min-h-screen bg-white dark:bg-black transition-colors flex flex-col">
      <header className="border-b border-black dark:border-white relative">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 py-4 sm:py-5">
          <div className="flex items-center justify-between">
            {/* Logo */}
            <Link 
              to="/" 
              className="text-lg sm:text-xl font-semibold hover:underline transition-all duration-200"
              onClick={closeMobileMenu}
            >
              Growwly
            </Link>
            
            {user && (
              <>
                {/* Desktop Navigation */}
                <div className="hidden md:flex items-center gap-2 lg:gap-3">
                  <button
                    onClick={toggleTheme}
                    disabled={isTransitioning}
                    className={`btn-secondary flex items-center gap-2 relative overflow-hidden px-3 py-2 ${
                      isTransitioning ? 'opacity-75 cursor-not-allowed' : ''
                    }`}
                    title={`Switch to ${theme === 'light' ? 'dark' : 'light'} mode`}
                  >
                    <div className={`transition-transform duration-300 ${isTransitioning ? 'scale-110' : ''}`}>
                      {theme === 'light' ? <Moon size={16} /> : <Sun size={16} />}
                    </div>
                    <span className="hidden xl:inline text-sm">
                      {theme === 'light' ? 'Dark' : 'Light'}
                    </span>
                    {isTransitioning && (
                      <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent animate-pulse" />
                    )}
                  </button>
                  
                  {location.pathname === '/' && (
                    <Link to="/add" className="btn-secondary flex items-center gap-2 px-3 py-2">
                      <Plus size={16} />
                      <span className="hidden lg:inline text-sm">Add Progress</span>
                    </Link>
                  )}
                  
                  <button
                    onClick={() => setShowPasswordModal(true)}
                    className="btn-secondary flex items-center gap-2 px-3 py-2"
                    title="Change Password"
                  >
                    <Lock size={16} />
                    <span className="hidden xl:inline text-sm">Password</span>
                  </button>
                  
                  <button
                    onClick={handleSignOut}
                    className="btn-secondary flex items-center gap-2 px-3 py-2"
                  >
                    <LogOut size={16} />
                    <span className="hidden lg:inline text-sm">Sign Out</span>
                  </button>
                </div>

                {/* Mobile Menu Button */}
                <button
                  onClick={(e) => {
                    e.stopPropagation()
                    setMobileMenuOpen(!mobileMenuOpen)
                  }}
                  className="md:hidden btn-secondary flex items-center gap-2 mobile-menu-button z-50 relative px-3 py-2"
                >
                  {mobileMenuOpen ? <X size={16} /> : <Menu size={16} />}
                  <span className="text-sm">Menu</span>
                </button>
              </>
            )}
          </div>
        </div>

        {/* Mobile Navigation Menu */}
        {user && mobileMenuOpen && (
          <>
            {/* Backdrop */}
            <div 
              className="fixed inset-0 bg-black bg-opacity-50 z-40 md:hidden"
              onClick={() => setMobileMenuOpen(false)}
            />
            
            {/* Menu */}
            <div className="absolute top-full left-0 right-0 bg-white dark:bg-black border-b border-black dark:border-white md:hidden z-50 mobile-menu">
              <div className="max-w-4xl mx-auto px-4 py-4 space-y-3">
                <button
                  onClick={() => {
                    toggleTheme()
                    closeMobileMenu()
                  }}
                  disabled={isTransitioning}
                  className={`btn-secondary w-full flex items-center justify-center gap-2 ${
                    isTransitioning ? 'opacity-75 cursor-not-allowed' : ''
                  }`}
                >
                  {theme === 'light' ? <Moon size={16} /> : <Sun size={16} />}
                  Switch to {theme === 'light' ? 'Dark' : 'Light'} Mode
                </button>
                
                {location.pathname === '/' && (
                  <Link 
                    to="/add" 
                    className="btn-secondary w-full flex items-center justify-center gap-2"
                    onClick={closeMobileMenu}
                  >
                    <Plus size={16} />
                    Add Progress
                  </Link>
                )}
                
                <button
                  onClick={() => {
                    setShowPasswordModal(true)
                    closeMobileMenu()
                  }}
                  className="btn-secondary w-full flex items-center justify-center gap-2"
                >
                  <Lock size={16} />
                  Change Password
                </button>
                
                <button
                  onClick={handleSignOut}
                  className="btn-secondary w-full flex items-center justify-center gap-2"
                >
                  <LogOut size={16} />
                  Sign Out
                </button>
              </div>
            </div>
          </>
        )}
      </header>
      
      <main className="max-w-4xl mx-auto px-4 py-6 sm:py-8 flex-1 w-full">
        {children}
      </main>

      <Footer />

      {/* Floating Bot Button - only show when user is logged in */}
      {user && <BotButton />}

      <ChangePasswordModal
        isOpen={showPasswordModal}
        onClose={() => setShowPasswordModal(false)}
      />
    </div>
  )
}